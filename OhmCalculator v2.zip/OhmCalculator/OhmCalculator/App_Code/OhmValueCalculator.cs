﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OhmCalculator
{

    public interface IOhmValueCalculator
    {
        /// <summary>
        /// Calculates the Ohm value of a resistor based on the band colors.
        /// </summary>
        /// <param name="bandAColor">The color of the first figure of component value band.</param>
        /// <param name="bandBColor">The color of the second significant figure band.</param>
        /// <param name="bandCColor">The color of the decimal multiplier band.</param>
        /// <param name="bandDColor">The color of the tolerance value band.</param>
        int CalculateOhmValue(string bandAColor, string bandBColor, string bandCColor, string bandDColor);
    }
    public class OhmValueCalculator : IOhmValueCalculator
    {
        private Dictionary<string, int> SignifiantFigures
        {
            get
            {
                return new Dictionary<string, int> {
                    {"black", 0},
                    {"brown", 1},
                    {"red", 2},
                    {"orange", 3},
                    {"yellow", 4},
                    {"green", 5},
                    {"blue", 6},
                    {"violet", 7},
                    {"gray", 8},
                    {"white", 9}
                };

            }
        }

        private Dictionary<string, int> Multiplier
        {
            get
            {
                return new Dictionary<string, int> {
                    {"pink", -3},
                    {"silver", -2},
                    {"gold", -1},
                    {"black", 0},
                    {"brown", 1},
                    {"red", 2},
                    {"orange", 3},
                    {"yellow", 4},
                    {"green", 5},
                    {"blue", 6},
                    {"violet", 7},
                    {"gray", 8},
                    {"white", 9}
                };
            }
        }

        private Dictionary<string, double> Tolerance
        {
            get
            {
                return new Dictionary<string, double> {
                    {"pink", 0},
                    {"silver", 0.10},
                    {"gold", 0.05},
                    {"black", 0},
                    {"brown", 0.01},
                    {"red", 0.02},
                    {"orange", 0},
                    {"yellow", 0.05},
                    {"green", 0.005},
                    {"blue", 0.0025},
                    {"violet", 0.001},
                    {"gray", 0.0005},
                    {"white", 0}
                };
            }
        }

        private T GetValidBandColor<T>(string bandColor, Dictionary<string, T> ColorDic)
        {

            if (!string.IsNullOrEmpty(bandColor) && ColorDic.ContainsKey(bandColor.ToLower().Trim()))
                return ColorDic[bandColor.ToLower().Trim()];
            else
                return default(T);
        }


        public int CalculateOhmValue(string bandAColor, string bandBColor, string bandCColor, string bandDColor)
        {
            int firstSignifiantFigures = 0;
            int secondSignifiantFigures = 0;
            int decimalMultiplier = 0;
            double tolerance = 0;
            int result = 0;

            firstSignifiantFigures = GetValidBandColor(bandAColor, SignifiantFigures);
            secondSignifiantFigures = GetValidBandColor(bandBColor, SignifiantFigures);
            decimalMultiplier = GetValidBandColor(bandCColor, Multiplier);
            tolerance = GetValidBandColor(bandDColor, Tolerance);
            
            if (tolerance == 0.0D)
                tolerance = 0.20;

            if (firstSignifiantFigures == 0) result = -199;
            if (secondSignifiantFigures == 0) result = -299;
            if (decimalMultiplier == 0) result = -399;

            if (result == 0)
            {
                int signifiantFigures = Convert.ToInt32(firstSignifiantFigures.ToString() + secondSignifiantFigures.ToString());
                result = (int)(signifiantFigures * Math.Pow(10, decimalMultiplier) * (1 + tolerance));
            }

            return result;
        }
    }
}