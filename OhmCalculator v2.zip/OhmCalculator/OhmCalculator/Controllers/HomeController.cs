﻿using OhmCalculator.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OhmCalculator.Controllers
{
    public class HomeController : Controller
    {
        

        public ActionResult Calculator()
        {
            CalculatorViewModels model = new CalculatorViewModels();
            return View(model);
        }


        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult Calculator(CalculatorViewModels model)
        {
            if (ModelState.IsValid)
            {
                var bandAColor = model.BandAColor;
                var bandBColor = model.BandBColor;
                var bandCColor = model.BandCColor;
                var bandDColor = model.BandDColor;

                OhmValueCalculator calc = new OhmValueCalculator();

                model.OhmValue = calc.CalculateOhmValue(bandAColor, bandBColor, bandCColor, bandDColor).ToString();
                return View(model);
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

    }
}