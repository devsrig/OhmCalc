﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(OhmCalculator.Startup))]
namespace OhmCalculator
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
