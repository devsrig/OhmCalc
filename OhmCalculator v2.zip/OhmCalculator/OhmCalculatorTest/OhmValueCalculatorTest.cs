﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OhmCalculator;

namespace OhmCalculatorTest
{
    [TestClass]
    public class OhmCalculatorTest
    {
        [TestMethod]
        public void CalculateOhmValue_AllBandColorPassed()
        {
            //Arrange
            int expected = 28350;
            var objOhmValueCalculator = new OhmValueCalculator();

            //Act
            var result = objOhmValueCalculator.CalculateOhmValue("Red", "Violet", "Orange", "Gold");

            //Assert

            Assert.AreEqual(expected,result);
        }


        [TestMethod]
        public void CalculateOhmValue_NotPassingSecondColor_ReturnNegative299()
        {
            //Arrange
            int expected = -299;
            var objOhmValueCalculator = new OhmValueCalculator();

            //Act
            var result = objOhmValueCalculator.CalculateOhmValue("Red", "", "Orange", "Gold");

            //Assert

            Assert.AreEqual(expected, result);
        }


        [TestMethod]
        public void CalculateOhmValue_NotPassingThirdColor_ReturnNegative399()
        {
            //Arrange
            int expected = -399;
            var objOhmValueCalculator = new OhmValueCalculator();

            //Act
            var result = objOhmValueCalculator.CalculateOhmValue("Red", "Violet", "", "Gold");

            //Assert

            Assert.AreEqual(expected, result);
        }

    }
}
